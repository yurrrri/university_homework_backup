#include <stdio.h>
#include <stdlib.h>

void selectionSort(int list[], int size){

	int i, j, temp;

	for (i=0; i<size; i++){
		list[i] = rand()%100;
	}
	
	printf("�߻��� ����: ");
	for(i=0;i<size;i++) 
		printf("%d ", list[i]);
	printf("\n");

    for (i=0; i<size; i++)
    {

        for (j=0; j<size-1; j++){
            if (list[j] > list[j+1])
            {                                 
                temp = list[j];
                list[j] = list[j + 1];
                list[j + 1] = temp;           
            }
        }
    }
	
	printf("���� ��: ");
	for (i=0; i<size; i++){
		printf("%d ", list[i]);
	}
	printf("\n");

}

int main(void){

	int size = 20;
	int list[20];

	selectionSort(list, size);
}
