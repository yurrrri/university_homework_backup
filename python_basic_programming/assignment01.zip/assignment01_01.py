# -*- coding: utf-8 -*-
'''
학번 : 20161048, 이름: 이유리
과제번호: 과제  1.1
제출일 : 2016.9.18
'''
x = 2*3 #x를 계산한다
print(x)

x = 2+3*4
print(x)

x = (2+3)*4
print(x)

x = 2*(4-1)
print(x)

x = -(2+3)
print(x)

x = 5/2
print(x)

x = 14/4
print(x)

x = 14//4
print(x)

x = 14%4
print(x)

x = 23//5
print(x)

x = 54 + 31 - 3
print(x)

x = 2**9
print(x)

x = 36%5
print(x)

x = 36%-5
print(x)

x = -5 % -5
print(x)

x = 4 + 4 ** 3 % 11
print(x)

x = 7 * 7 % 21
print(x)

x = 4 // 9 ** 2 % 3
print(x)

x = 8 - 7 % -5
print(x)

x = 0 // -2
print(x)