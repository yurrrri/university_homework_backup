﻿#-*- coding:utf-8 -*-

'''
학번: 20161048 이름: 이유리
과제번호: 과제  13
제출일자: 2016.11.27
'''

from yuri import lectureTurtle as tut
import turtle
import time
from random import randint as randi

side=50
image = {"left":"robot_Leftward.gif", "up":"robot_Upward.gif", "right":"robot_Rightward.gif",  
         "down":"robot_Downward.gif", "gem":"gem.gif"}

class Window:
    def __init__(self):
        self.screen=turtle.Screen()
        
        for direction in image:
            self.screen.addshape(image[direction])

class Maze:
    def __init__(self,stageNo):
        self.blockList=[]
        self.blockList.clear()
        
        inputFile = open('stage'+str(stageNo) + '.txt', 'r')
        for point in inputFile:
            x, y = point.split(',')
            x, y = int(x), int(y)
            self.blockList.append([x, y])
            
        self.mazePen=turtle.Turtle()  

    def drawMaze(self,stageNo):
        self.mazePen.hideturtle()
        self.mazePen.speed(0)
        
        self.mazePen.penup()
        self.mazePen.goto(-250,330)
        self.mazePen.pendown()
        self.mazePen.pencolor('blue')
        self.mazePen.write('stage'+str(stageNo),font=('impact',17,'italic'))
        
        tut.writeText(self.mazePen, '횟수 : ', -250, 310)
        
        tut.drawRectangle(self.mazePen, 0, 0, side*11, side*11, b_color='black')
        for x in range(-5, 6):
            tut.writeText(self.mazePen, x, x*side, 5.7*side, t_color='black')
            tut.writeText(self.mazePen, x, -5.8*side, x*side, t_color='black')                 
            for y in range(-5, 6):
                cell = [x, y]
                if cell in self.blockList:
                    tut.drawRectangle(self.mazePen, cell[0]*side, cell[1]*side, side, side, b_color='black', f_color='black')
                else:
                    tut.drawRectangle(self.mazePen, cell[0]*side, cell[1]*side, side, side, b_color='black', f_color='white')


class Counter:
    def __init__(self):
        self.count=0
        self.textPen=turtle.Turtle()
        
    def showCount(self):
        self.textPen.clear()
        self.textPen.hideturtle()
        
        tut.writeText(self.textPen,str(self.count),-200,310)
    
class Gem:
    def __init__(self):
        self.position=[-5,5]
        
        self.gemPen=turtle.Turtle()
        self.gemPen.shape(image['gem'])
        self.gemPen.hideturtle()
        self.gemPen.penup()
        self.gemPen.goto(self.position[0]*side, self.position[1]*side)
        self.gemPen.showturtle()
        
class Robot:
    def __init__(self):
            
        self.position=[5,-5]
        self.robotPen=turtle.Turtle()
        self.robotPen.speed(0)
        
    def getNextPosition(self,maze):
        
        repeatFlag = True
    
        while repeatFlag:
            
            nextRobotPos = self.position[:]
        
            dirVal = randi(1, 4)
                
            if dirVal == 1 :            
                nextRobotPos[0] -= 1
                self.robotPen.shape(image["left"])           
            elif dirVal == 2 :
                nextRobotPos[0] += 1
                self.robotPen.shape(image["right"]) 
            elif dirVal == 3 :
                nextRobotPos[1] -= 1
                self.robotPen.shape(image["down"])    
            else :
                nextRobotPos[1] += 1
                self.robotPen.shape(image["up"])  
    
            if nextRobotPos not in maze.blockList and -5<=nextRobotPos[0]<=5 and -5<=nextRobotPos[1]<=5 : 
                repeatFlag = False

        self.position=nextRobotPos
        
    def moveRobot(self):
        self.robotPen.clear()
        self.robotPen.speed(0)
        self.robotPen.penup()
        self.robotPen.goto(self.position[0]*side, self.position[1]*side)
        
    def findGem(self,gem,counter,maze):
        self.moveRobot()
        
        while self.position!=gem.position:
            self.getNextPosition(maze)
            self.moveRobot()
            
            counter.count+=1
            counter.showCount()
            
            time.sleep(0.5)
        
def main():
    window=Window()
    robot=Robot()
    
    window.screen.setup(750,750)
    
    noStages=2
    
    for stage in range(1, noStages+1):
        window.screen.clear()
        maze=Maze(stage)
        maze.drawMaze(stage)
        
        gem=Gem()
        counter=Counter()
        
        robot.findGem(gem,counter,maze)
        
    turtle.done()
        
main()