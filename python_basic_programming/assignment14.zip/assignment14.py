#-*- coding:utf-8 -*-

'''
학번: 20161048 이름: 이유리
과제번호: 과제  14
제출일자: 2016.11.2
'''

from yuri import lectureTurtle as tut
import turtle
import time

side=50
image = {"left":"robot_Leftward.gif", "up":"robot_Upward.gif", "right":"robot_Rightward.gif",  
         "down":"robot_Downward.gif", "gem":"gem.gif"}

class Window:
    def __init__(self,robot,counter,maze):
        self.robot=robot
        self.counter=counter
        self.maze=maze
        
        self.screen=turtle.Screen()
        
        for im in image:
            self.screen.addshape(image[im])

        
        self.screen.onkey(self.upward, "Up")
        self.screen.onkey(self.downward, "Down")
        self.screen.onkey(self.leftward, "Left")
        self.screen.onkey(self.rightward, "Right")

    def setDefaultImage(self):
        self.robot.robotPen.hideturtle()
        self.robot.robotPen.shape(image["left"])
        self.robot.robotPen.penup()
        self.robot.robotPen.goto(self.robot.position[0]*side, self.robot.position[1]*side)
        self.robot.robotPen.showturtle()
        
    def upward(self):
        nextRobotPos=list(self.robot.position)
        nextRobotPos[1]+=1
        
        if nextRobotPos not in self.maze.blockList and -5<=nextRobotPos[0]<=5 and -5<=nextRobotPos[1]<=5:
            self.robot.position=nextRobotPos        
            self.robot.robotPen.shape(image["up"])
            self.robot.robotPen.goto(self.robot.position[0]*side,self.robot.position[1]*side)
            self.counter.count+=1
            self.counter.showCount()

    def downward(self):
        nextRobotPos=list(self.robot.position)
        nextRobotPos[1]-=1
        
        if nextRobotPos not in self.maze.blockList and -5<=nextRobotPos[0]<=5 and -5<=nextRobotPos[1]<=5:
            self.robot.position=nextRobotPos         
            self.robot.robotPen.shape(image["down"])
            self.robot.robotPen.goto(self.robot.position[0]*side,self.robot.position[1]*side)
            self.counter.count+=1
            self.counter.showCount()

    def leftward(self):
        nextRobotPos=list(self.robot.position)
        nextRobotPos[0]-=1
        
        if nextRobotPos not in self.maze.blockList and -5<=nextRobotPos[0]<=5 and -5<=nextRobotPos[1]<=5:
            self.robot.position=nextRobotPos         
            self.robot.robotPen.shape(image["left"])
            self.robot.robotPen.goto(self.robot.position[0]*side,self.robot.position[1]*side)
            self.counter.count+=1
            self.counter.showCount()
                  
    def rightward(self):
        nextRobotPos=list(self.robot.position)
        nextRobotPos[0]+=1
        
        if nextRobotPos not in self.maze.blockList and -5<=nextRobotPos[0]<=5 and -5<=nextRobotPos[1]<=5:
            self.robot.position=nextRobotPos   
            self.robot.robotPen.shape(image["right"])
            self.robot.robotPen.goto(self.robot.position[0]*side,self.robot.position[1]*side)
            self.counter.count+=1
            self.counter.showCount()
            
class Maze:
    def __init__(self,stageNo):
        self.blockList=[]
        self.blockList.clear()
        
        inputFile = open('stage'+str(stageNo) + '.txt', 'r')
        for point in inputFile:
            x, y = point.split(',')
            x, y = int(x), int(y)
            self.blockList.append([x, y])
            
        self.mazePen=turtle.Turtle()  

    def drawMaze(self,stageNo):
        self.mazePen.hideturtle()
        self.mazePen.speed(0)
        
        self.mazePen.penup()
        self.mazePen.goto(-250,330)
        self.mazePen.pendown()
        self.mazePen.pencolor('blue')
        self.mazePen.write('stage'+str(stageNo),font=('impact',17,'italic'))
        
        tut.writeText(self.mazePen, '횟수 : ', -250, 310)
        
        tut.drawRectangle(self.mazePen, 0, 0, side*11, side*11, b_color='black')
        for x in range(-5, 6):
            tut.writeText(self.mazePen, x, x*side, 5.7*side, t_color='black')
            tut.writeText(self.mazePen, x, -5.8*side, x*side, t_color='black')                 
            for y in range(-5, 6):
                cell = [x, y]
                if cell in self.blockList:
                    tut.drawRectangle(self.mazePen, cell[0]*side, cell[1]*side, side, side, b_color='black', f_color='black')
                else:
                    tut.drawRectangle(self.mazePen, cell[0]*side, cell[1]*side, side, side, b_color='black', f_color='white')

class Counter:
    def __init__(self):
        self.count=0
        self.textPen=turtle.Turtle()
        
    def showCount(self):
        self.textPen.clear()
        self.textPen.hideturtle()
        
        tut.writeText(self.textPen,str(self.count),-200,310)
    
class Gem:
    def __init__(self):
        self.position=[-5,5]
        
        self.gemPen=turtle.Turtle()
        self.gemPen.shape(image['gem'])
        self.gemPen.hideturtle()
        self.gemPen.penup()
        self.gemPen.goto(self.position[0]*side, self.position[1]*side)
        self.gemPen.showturtle()
        
class Robot:
    def __init__(self):
            
        self.position=[5,-5]
        
        self.robotPen=turtle.Turtle()
            
def main():
    
    noStages=2
    
    for stage in range(1, noStages+1):
        
        maze=Maze(stage)
        maze.drawMaze(stage)
            
        robot=Robot()
        counter=Counter()
        counter.showCount()
        
        window=Window(robot,counter,maze)
        window.screen.setup(750, 750)
        gem=Gem()
        window.setDefaultImage()
        
        while robot.position!=gem.position:
            counter=Counter()
            window.screen.listen()
        
        time.sleep(1)    
        window.screen.clear()    
    window.screen.mainloop()    
    
    turtle.done()
        
main()